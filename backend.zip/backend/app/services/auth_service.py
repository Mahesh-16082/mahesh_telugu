
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.cors.config import settings
from app.cors.security import (
    create_access_token,
    generate_otp,
    hash_otp,
    verify_otp_hash,
)
from app.models.email_login_otp import EmailLoginOTP
from app.models.user import User
from app.schemas.auth_otp import OTPRequestResponse, OTPVerifyResponse
from app.services.email_service import send_otp_email


def request_login_otp(email: str, db: Session) -> OTPRequestResponse:
    """Create and email an OTP for the configured administrator."""
    normalized_email = email.strip().lower()
    admin_email = settings.admin_email.strip().lower()

    # This initial implementation supports the configured admin only.
    if normalized_email != admin_email:
        raise ValueError("Unable to process login request for this email.")

    user = db.scalar(
        select(User).where(
            User.email == normalized_email,
            User.is_active.is_(True),
        )
    )

    if user is None:
        raise ValueError("The administrator account is not available.")

    now = datetime.now(timezone.utc)

    latest_otp = db.scalar(
        select(EmailLoginOTP)
        .where(
            EmailLoginOTP.email == normalized_email,
            EmailLoginOTP.is_used.is_(False),
        )
        .order_by(EmailLoginOTP.created_at.desc())
        .limit(1)
    )

    if latest_otp is not None:
        created_at = latest_otp.created_at

        # PostgreSQL may return a naive datetime depending on column/driver.
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)

        elapsed = (now - created_at).total_seconds()
        remaining = settings.otp_resend_cooldown_seconds - elapsed

        if remaining > 0:
            raise ValueError(
                f"Please wait {int(remaining) + 1} seconds before requesting another OTP."
            )

    otp = generate_otp()
    otp_record = EmailLoginOTP(
        email=normalized_email,
        otp_hash=hash_otp(otp),
        expires_at=now + timedelta(minutes=settings.otp_expire_minutes),
        attempts=0,
        is_used=False,
        created_at=now,
    )

    try:
        # Persist first so an email delivery error doesn't lose the OTP record.
        db.add(otp_record)
        db.commit()
        db.refresh(otp_record)

        send_otp_email(normalized_email, otp)
    except Exception:
        db.rollback()
        raise

    return OTPRequestResponse(
        message="If the account is eligible, a login code has been sent.",
        expires_in_seconds=settings.otp_expire_minutes * 60,
    )


def verify_login_otp(
    email: str,
    otp: str,
    db: Session,
) -> OTPVerifyResponse:
    """Verify an OTP and issue a JWT once the code is valid."""
    normalized_email = email.strip().lower()
    admin_email = settings.admin_email.strip().lower()

    if normalized_email != admin_email:
        raise ValueError("Invalid or expired OTP.")

    now = datetime.now(timezone.utc)

    # Lock the newest unused OTP record while checking attempts and validity.
    otp_record = db.scalar(
        select(EmailLoginOTP)
        .where(
            EmailLoginOTP.email == normalized_email,
            EmailLoginOTP.is_used.is_(False),
        )
        .order_by(EmailLoginOTP.created_at.desc())
        .limit(1)
        .with_for_update()
    )

    if otp_record is None:
        raise ValueError("Invalid or expired OTP.")

    expires_at = otp_record.expires_at
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)

    if expires_at <= now:
        otp_record.is_used = True
        db.commit()
        raise ValueError("Invalid or expired OTP.")

    if otp_record.attempts >= settings.otp_max_attempts:
        otp_record.is_used = True
        db.commit()
        raise ValueError("Maximum verification attempts exceeded. Request a new OTP.")

    if not verify_otp_hash(otp, otp_record.otp_hash):
        otp_record.attempts += 1

        if otp_record.attempts >= settings.otp_max_attempts:
            otp_record.is_used = True

        db.commit()
        raise ValueError("Invalid or expired OTP.")

    user = db.scalar(
        select(User).where(
            User.email == normalized_email,
            User.is_active.is_(True),
        )
    )

    if user is None:
        otp_record.is_used = True
        db.commit()
        raise ValueError("Invalid or expired OTP.")

    # Consume the OTP before returning the access token.
    otp_record.is_used = True
    db.commit()

    token = create_access_token(
        subject=user.email,
        role=user.role,
    )

    return OTPVerifyResponse(
        message="Login successful.",
        access_token=token,
        token_type="bearer",
    )
